function first () {
    document.getElementById("slideimage").src="./img/img2.jpg";
}
function second () {
    document.getElementById("slideimage").src="./img/img3.jpg";
}
function third () {
    document.getElementById("slideimage").src="./img/img4.jpg";
}



setInterval(first,2000);
setInterval(second,4000);
setInterval(third,6000);
